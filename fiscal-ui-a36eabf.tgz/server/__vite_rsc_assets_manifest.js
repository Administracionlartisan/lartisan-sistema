export default {
  "bootstrapScriptContent": "import(\"/_next/static/chunks/index-CH6ByoYj.js\")",
  "clientReferenceDeps": {
    "6efdf509a785": {
      "js": [
        "/_next/static/chunks/page-CzG7bobE.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-BgSIrAUN.js",
        "/_next/static/chunks/index-CH6ByoYj.js"
      ],
      "css": [
        "/_next/static/css/page.DvzRu_Si.css"
      ]
    },
    "9276801271d6": {
      "js": [
        "/_next/static/chunks/index-CH6ByoYj.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-BgSIrAUN.js"
      ],
      "css": []
    },
    "0b874ad30386": {
      "js": [
        "/_next/static/chunks/index-CH6ByoYj.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-BgSIrAUN.js"
      ],
      "css": []
    },
    "593f344dc510": {
      "js": [
        "/_next/static/chunks/index-CH6ByoYj.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-BgSIrAUN.js"
      ],
      "css": []
    },
    "bad85346fc72": {
      "js": [
        "/_next/static/chunks/index-CH6ByoYj.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-BgSIrAUN.js"
      ],
      "css": []
    },
    "15c18cfaeeff": {
      "js": [
        "/_next/static/chunks/layout-segment-context-Ca-LXEK8.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/index-CH6ByoYj.js",
        "/_next/static/chunks/framework-BgSIrAUN.js"
      ],
      "css": []
    },
    "8c0f216c4604": {
      "js": [
        "/_next/static/chunks/index-CH6ByoYj.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-BgSIrAUN.js"
      ],
      "css": []
    }
  },
  "serverResources": {
    "app/layout.tsx": {
      "js": [],
      "css": [
        "/_next/static/css/index.Clj4LAYL.css"
      ]
    }
  }
}